# HydroMind KB Upload System — Vercel Deployment
# Version 2.0 | Vercel Serverless | No Express needed

# ═══════════════════════════════════════════════
# STEP 1 — Add environment variables to Vercel
# ═══════════════════════════════════════════════
# Go to: vercel.com → Your Project → Settings → Environment Variables
# Add these 3 variables:

# OPENAI_API_KEY         = (your OpenAI key from platform.openai.com)
# SUPABASE_URL           = https://frqefpoheewbornozvhc.supabase.co
# SUPABASE_SERVICE_KEY   = (from supabase.com → Project Settings → API → service_role)

# ═══════════════════════════════════════════════
# STEP 2 — Install new npm packages
# ═══════════════════════════════════════════════
cd ~/Desktop/hydromind-frontend
npm install @supabase/supabase-js pdf-parse

# ═══════════════════════════════════════════════
# STEP 3 — Copy new files into your project
# ═══════════════════════════════════════════════

# Copy the 3 API route files:
# kb-upload.js     → ~/Desktop/hydromind-frontend/api/kb-upload.js
# kb-documents.js  → ~/Desktop/hydromind-frontend/api/kb-documents.js
# kb-search.js     → ~/Desktop/hydromind-frontend/api/kb-search.js

# Copy the KB Manager page:
# kb-manager.html  → ~/Desktop/hydromind-frontend/pages/kb-manager.html
# kb-manager.html  → ~/Desktop/hydromind-frontend/public/pages/kb-manager.html

# Copy the updated package.json:
# package.json     → ~/Desktop/hydromind-frontend/package.json  (REPLACE existing)

# ═══════════════════════════════════════════════
# STEP 4 — Deploy
# ═══════════════════════════════════════════════
cd ~/Desktop/hydromind-frontend
git add api/kb-upload.js api/kb-documents.js api/kb-search.js
git add pages/kb-manager.html public/pages/kb-manager.html
git add package.json
git commit -m "feat: add KB upload system with vector search"
git push

# ═══════════════════════════════════════════════
# STEP 5 — Access KB Manager
# ═══════════════════════════════════════════════
# After deploy, access at:
# https://hydromindai.com/pages/kb-manager.html
#
# Login with your admin account (must have is_premium = true in DB)
# Upload any PDF manual
# It will be chunked, embedded, and stored in Supabase automatically

# ═══════════════════════════════════════════════
# VERCEL ENVIRONMENT VARIABLES SUMMARY
# ═══════════════════════════════════════════════
# Variable              Where to get it
# ─────────────────────────────────────────────
# OPENAI_API_KEY        platform.openai.com → API Keys → Create
# SUPABASE_URL          supabase.com → Project → Settings → API → Project URL
# SUPABASE_SERVICE_KEY  supabase.com → Project → Settings → API → service_role key
# ANTHROPIC_API_KEY     (already set — used by existing chat.js)
# RESEND_API_KEY        (already set — used by existing feedback.js)

# ═══════════════════════════════════════════════
# DATABASE — Already Done ✅
# ═══════════════════════════════════════════════
# pgvector extension: enabled
# kb_chunks.embedding: migrated to vector(1536)
# HNSW index: created
# search_kb RPC function: deployed
# All security warnings: fixed
