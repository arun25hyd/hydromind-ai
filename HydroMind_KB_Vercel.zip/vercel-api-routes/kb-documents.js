// ============================================================
// /api/kb-documents.js — HydroMind KB Document Management
// GET:    list all documents (premium users)
// DELETE: delete document + all its chunks (premium users)
// ============================================================

import { createClient } from '@supabase/supabase-js';

function getSupabase() {
  return createClient(
    process.env.SUPABASE_URL,
    process.env.SUPABASE_SERVICE_KEY
  );
}

function setCORS(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Access-Control-Allow-Methods', 'GET, DELETE, OPTIONS');
}

async function verifyAuth(req) {
  const auth = req.headers.authorization;
  if (!auth || !auth.startsWith('Bearer ')) return null;
  const token = auth.split(' ')[1];
  const supabase = getSupabase();
  const { data: { user }, error } = await supabase.auth.getUser(token);
  if (error || !user) return null;
  const { data: profile } = await supabase
    .from('users')
    .select('id, is_premium')
    .eq('id', user.id)
    .single();
  return profile;
}

export default async function handler(req, res) {
  setCORS(res);
  if (req.method === 'OPTIONS') return res.status(200).end();

  const user = await verifyAuth(req);
  if (!user) return res.status(401).json({ error: 'Authentication required' });
  if (!user.is_premium) return res.status(403).json({ error: 'Premium required' });

  const supabase = getSupabase();

  // ── GET: list all documents ──
  if (req.method === 'GET') {
    const { data, error } = await supabase
      .from('kb_documents')
      .select('id, name, category, description, page_count, char_count, chunk_count, status, created_at')
      .order('created_at', { ascending: false });

    if (error) return res.status(500).json({ error: error.message });
    return res.status(200).json({ documents: data });
  }

  // ── DELETE: remove document and all its chunks ──
  if (req.method === 'DELETE') {
    const { id } = req.query;
    if (!id) return res.status(400).json({ error: 'Document ID required' });

    // Delete chunks first (FK constraint)
    await supabase.from('kb_chunks').delete().eq('doc_id', id);

    const { error } = await supabase
      .from('kb_documents')
      .delete()
      .eq('id', id);

    if (error) return res.status(500).json({ error: error.message });
    return res.status(200).json({ success: true });
  }

  return res.status(405).json({ error: 'Method not allowed' });
}
