// ============================================================
// /api/kb-upload.js — HydroMind KB Manual Upload
// POST: receives PDF as base64 JSON, chunks, embeds, stores
// Auth: requires valid JWT + is_premium = true
// ============================================================

import { createClient } from '@supabase/supabase-js';

// ── Supabase service-role client (bypasses RLS) ──
function getSupabase() {
  return createClient(
    process.env.SUPABASE_URL,
    process.env.SUPABASE_SERVICE_KEY
  );
}

// ── CORS headers (match existing chat.js pattern) ──
function setCORS(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
}

// ── Verify JWT and check premium ──
async function verifyAuth(req) {
  const auth = req.headers.authorization;
  if (!auth || !auth.startsWith('Bearer ')) return null;
  const token = auth.split(' ')[1];

  const supabase = getSupabase();
  const { data: { user }, error } = await supabase.auth.getUser(token);
  if (error || !user) return null;

  // Check premium status in users table
  const { data: profile } = await supabase
    .from('users')
    .select('id, is_premium')
    .eq('id', user.id)
    .single();

  return profile;
}

// ── Extract text from PDF base64 using pdf-parse ──
async function extractTextFromBase64(base64Data) {
  const { default: pdfParse } = await import('pdf-parse/lib/pdf-parse.js');
  const buffer = Buffer.from(base64Data, 'base64');
  const data = await pdfParse(buffer);
  return { text: data.text, pageCount: data.numpages };
}

// ── Chunk text: 500-token chunks with 50-token overlap ──
function chunkText(text, docName) {
  const CHUNK_CHARS = 2000;   // ~500 tokens × 4 chars/token
  const OVERLAP_CHARS = 200;  // ~50 tokens overlap

  const cleaned = text
    .replace(/\r\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .replace(/[ \t]+/g, ' ')
    .trim();

  const chunks = [];
  let start = 0;
  let index = 0;

  while (start < cleaned.length) {
    let end = start + CHUNK_CHARS;

    // Break at sentence boundary if possible
    if (end < cleaned.length) {
      const bp = cleaned.lastIndexOf('. ', end);
      if (bp > start + CHUNK_CHARS * 0.5) end = bp + 1;
    }

    const content = cleaned.slice(start, end).trim();
    if (content.length > 50) {
      chunks.push({ content, chunkIndex: index, docName });
      index++;
    }
    start = end - OVERLAP_CHARS;
    if (start <= 0) start = end;
  }

  return chunks;
}

// ── Generate embeddings via OpenAI (batch) ──
async function generateEmbeddings(texts) {
  const BATCH = 100;
  const allEmbeddings = [];

  for (let i = 0; i < texts.length; i += BATCH) {
    const batch = texts.slice(i, i + BATCH).map(t => t.replace(/\n/g, ' '));

    const resp = await fetch('https://api.openai.com/v1/embeddings', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: 'text-embedding-3-small',
        input: batch,
        dimensions: 1536
      })
    });

    if (!resp.ok) {
      const err = await resp.json();
      throw new Error('OpenAI embedding error: ' + (err.error?.message || resp.status));
    }

    const data = await resp.json();
    const sorted = data.data.sort((a, b) => a.index - b.index);
    allEmbeddings.push(...sorted.map(d => d.embedding));

    // Rate limit buffer between batches
    if (i + BATCH < texts.length) {
      await new Promise(r => setTimeout(r, 250));
    }
  }

  return allEmbeddings;
}

// ── Main handler ──
export default async function handler(req, res) {
  setCORS(res);

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  // ── Auth check ──
  const user = await verifyAuth(req);
  if (!user) return res.status(401).json({ error: 'Authentication required' });
  if (!user.is_premium) return res.status(403).json({ error: 'Premium subscription required to upload manuals' });

  // ── Validate request body ──
  const { fileName, fileBase64, category, description } = req.body;
  if (!fileName || !fileBase64) {
    return res.status(400).json({ error: 'fileName and fileBase64 are required' });
  }
  if (!fileBase64.length > 50 * 1024 * 1024 * 1.37) { // base64 overhead ~37%
    return res.status(400).json({ error: 'File exceeds 50MB limit' });
  }

  const docName = fileName.replace(/\.pdf$/i, '').replace(/[^a-zA-Z0-9\s\-_]/g, '').trim();
  const supabase = getSupabase();

  // ── Duplicate check ──
  const { data: existing } = await supabase
    .from('kb_documents')
    .select('id')
    .eq('name', docName)
    .maybeSingle();

  if (existing) {
    return res.status(409).json({ error: `"${docName}" already exists. Delete it first or rename the file.` });
  }

  // ── Create document record (status: processing) ──
  const { data: doc, error: docErr } = await supabase
    .from('kb_documents')
    .insert({
      name: docName,
      category: category || 'General',
      description: description || '',
      uploaded_by: user.id,
      status: 'processing'
    })
    .select()
    .single();

  if (docErr) return res.status(500).json({ error: 'DB error: ' + docErr.message });

  try {
    // ── Extract text ──
    const { text, pageCount } = await extractTextFromBase64(fileBase64);

    if (!text || text.trim().length < 100) {
      await supabase.from('kb_documents').delete().eq('id', doc.id);
      return res.status(422).json({ error: 'Could not extract text. PDF may be scanned/image-based.' });
    }

    // ── Chunk ──
    const chunks = chunkText(text, docName);
    if (chunks.length === 0) {
      await supabase.from('kb_documents').delete().eq('id', doc.id);
      return res.status(422).json({ error: 'No text chunks could be generated.' });
    }

    // ── Generate embeddings ──
    const embeddings = await generateEmbeddings(chunks.map(c => c.content));

    // ── Store chunks in batches of 50 ──
    const rows = chunks.map((chunk, i) => ({
      doc_id: doc.id,
      doc_name: docName,
      category: category || 'General',
      content: chunk.content,
      chunk_index: chunk.chunkIndex,
      embedding: `[${embeddings[i].join(',')}]`
    }));

    for (let i = 0; i < rows.length; i += 50) {
      const { error: chunkErr } = await supabase
        .from('kb_chunks')
        .insert(rows.slice(i, i + 50));
      if (chunkErr) throw new Error('Chunk insert error: ' + chunkErr.message);
    }

    // ── Update document record to ready ──
    await supabase
      .from('kb_documents')
      .update({
        page_count: pageCount,
        char_count: text.length,
        chunk_count: chunks.length,
        status: 'ready'
      })
      .eq('id', doc.id);

    return res.status(200).json({
      success: true,
      document: {
        id: doc.id,
        name: docName,
        pageCount,
        chunkCount: chunks.length,
        category: category || 'General',
        status: 'ready'
      }
    });

  } catch (err) {
    // Mark document as error state
    await supabase
      .from('kb_documents')
      .update({ status: 'error' })
      .eq('id', doc.id);

    console.error('[KB Upload Error]', err.message);
    return res.status(500).json({ error: 'Processing failed: ' + err.message });
  }
}

// Disable Vercel's default body size limit (PDFs can be large)
export const config = {
  api: {
    bodyParser: {
      sizeLimit: '50mb'
    }
  }
};
